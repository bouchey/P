<?php

/**
 * Enregistre un mouvement de stock dans la table stock_movements
 */
function stock_add_movement(PDO $pdo, int $product_id, string $type, int $quantity, string $source, string $ref_id = null): bool {

    if (!in_array($type, ['IN', 'OUT', 'ADJ'])) {
        throw new Exception("Type mouvement invalide : $type");
    }

    // INSERT correct (colonnes EXACTES)
    $stmt = $pdo->prepare("
        INSERT INTO stock_movements (product_id, type, quantity, source, ref_id)
        VALUES (:pid, :type, :qty, :source, :ref)
    ");
    $stmt->execute([
        'pid'    => $product_id,
        'type'   => $type,
        'qty'    => $quantity,
        'source' => $source,
        'ref'    => $ref_id
    ]);

    return true;
}


/**
 * Calcule les niveaux de stock réels depuis la table stock_movements
 */
function stock_levels(PDO $pdo): array {
    $sql = "
        SELECT 
            p.id,
            p.sku,
            p.name,
            p.reorder_level,
            COALESCE(SUM(
                CASE 
                    WHEN m.type = 'IN'  THEN m.quantity
                    WHEN m.type = 'OUT' THEN -m.quantity
                    WHEN m.type = 'ADJ' THEN m.quantity
                    ELSE 0
                END
            ), 0) AS stock_qty
        FROM products p
        LEFT JOIN stock_movements m ON m.product_id = p.id
        GROUP BY p.id
        ORDER BY p.sku
    ";

    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}


/**
 * Renvoie uniquement les produits en rupture (stock < seuil)
 */
function low_stock(PDO $pdo): array {
    $all = stock_levels($pdo);
    $lows = [];

    foreach ($all as $p) {
        if ($p['reorder_level'] > 0 && $p['stock_qty'] < $p['reorder_level']) {
            $lows[] = $p;
        }
    }
    return $lows;
}

?>

<?php
require('makefont.php');
MakeFont('../font/DejaVuSans.ttf', 'cp1252');
echo "✅ Police DejaVuSans générée dans le dossier /font";
?>

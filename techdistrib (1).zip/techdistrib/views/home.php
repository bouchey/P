<div class="home-banner">
    <img src="public/img/Accueil.jpg" alt="Accueil TechDistrib">
</div>

<h2>Bienvenue</h2>
<p>Ton PGI est bien branché. Utilise le menu ci-dessus.</p>

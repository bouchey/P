<?php
require __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/stock.php';

if (!isset($_GET['commande_id'])) {
    die("❌ Commande non trouvée.");
}

$commandeId = (int) $_GET['commande_id'];

/* ----------------------------------------------------------
   1) ANNULATION D’UNE LIGNE DE COMMANDE
-----------------------------------------------------------*/
if (isset($_GET['annuler_produit'])) {
    $detailId = (int) $_GET['annuler_produit'];

    // 1️⃣ Récupérer la ligne
    $stmt = $pdo->prepare("
        SELECT product_id, quantite, prix_unitaire, annule
        FROM details_commandes
        WHERE id = :id
    ");
    $stmt->execute(['id' => $detailId]);
    $detail = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($detail && $detail['annule'] == 0) {

        try {
            $pdo->beginTransaction();

            // 2️⃣ Annuler la ligne
            $pdo->prepare("
                UPDATE details_commandes
                SET annule = 1
                WHERE id = :id
            ")->execute(['id' => $detailId]);

            // 3️⃣ Ajouter un mouvement stock (IN)
            stock_add_movement(
                $pdo,
                $detail['product_id'],
                'IN',
                $detail['quantite'],
                'SALE_CANCEL_LINE',
                '#CMD'.$commandeId
            );

            // 4️⃣ Recalculer total
            $stmt = $pdo->prepare("
                SELECT SUM(quantite * prix_unitaire)
                FROM details_commandes
                WHERE commande_id = :cid AND annule = 0
            ");
            $stmt->execute(['cid' => $commandeId]);
            $newTotal = $stmt->fetchColumn() ?? 0;

            // 5️⃣ MAJ commande
            $pdo->prepare("
                UPDATE commandes
                SET total = :t
                WHERE id = :id
            ")->execute([
                't' => $newTotal,
                'id' => $commandeId
            ]);

            $pdo->commit();
            echo "<p style='color:orange;'>⚠️ Produit annulé et stock remis.</p>";

        } catch (Exception $e) {
            $pdo->rollBack();
            echo "<p style='color:red;'>❌ Erreur : ".$e->getMessage()."</p>";
        }
    }
}

/* ----------------------------------------------------------
   2) LISTER LES PRODUITS DE LA COMMANDE
-----------------------------------------------------------*/
$stmt = $pdo->prepare("
    SELECT d.id AS detail_id, p.name, d.quantite, d.prix_unitaire, d.annule
    FROM details_commandes d
    JOIN products p ON d.product_id = p.id
    WHERE d.commande_id = :id
");
$stmt->execute(['id' => $commandeId]);
$produits = $stmt->fetchAll(PDO::FETCH_ASSOC);

// total commande
$stmt = $pdo->prepare("SELECT total FROM commandes WHERE id = :id");
$stmt->execute(['id' => $commandeId]);
$totalCommande = $stmt->fetchColumn() ?? 0;
?>

<h2>Produits de la commande #<?php echo $commandeId; ?></h2>

<table border="1" cellpadding="5">
<tr>
  <th>Produit</th>
  <th>Quantité</th>
  <th>Prix</th>
  <th>Total ligne</th>
  <th>Statut</th>
  <th>Action</th>
</tr>

<?php foreach ($produits as $p): 
    $totalLigne = $p['quantite'] * $p['prix_unitaire'];
    $statut = $p['annule'] ? "❌ Annulé" : "✅ Actif";
    $style = $p['annule'] ? "style='text-decoration: line-through; color: gray;'" : "";
    $bouton = $p['annule'] 
        ? "<span style='color:gray;'>—</span>"
        : "<a href='modifier_details.php?commande_id=$commandeId&annuler_produit={$p['detail_id']}'
           onclick=\"return confirm('Annuler ce produit ?');\">Annuler</a>";
?>
<tr <?= $style ?>>
    <td><?= htmlspecialchars($p['name']) ?></td>
    <td align="center"><?= $p['quantite'] ?></td>
    <td align="right"><?= number_format($p['prix_unitaire'], 2, ',', ' ') ?> €</td>
    <td align="right"><?= number_format($totalLigne, 2, ',', ' ') ?> €</td>
    <td align="center"><?= $statut ?></td>
    <td align="center"><?= $bouton ?></td>
</tr>
<?php endforeach; ?>
</table>

<h3>Total actuel : 
   <span style="color:blue;">
   <?= number_format($totalCommande, 2, ',', ' ') ?> €
   </span>
</h3>

<a href="index.php?r=sales_orders">⬅ Retour</a>

<?php
require __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/stock.php';

// Vérifie que l'ID existe
if (!isset($_GET['id'])) {
    die("❌ Aucune commande sélectionnée.");
}

$commandeId = (int) $_GET['id'];

try {
    $pdo->beginTransaction();

    // 1️⃣ Récupérer toutes les lignes actives de la commande
    $stmt = $pdo->prepare("
        SELECT product_id, quantite
        FROM details_commandes
        WHERE commande_id = :id AND annule = 0
    ");
    $stmt->execute(['id' => $commandeId]);
    $lignes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2️⃣ Pour chaque ligne → remettre le stock via stock_add_movement()
    foreach ($lignes as $l) {

        stock_add_movement(
            $pdo,
            $l['product_id'],
            'IN',                    // retour stock
            $l['quantite'],
            'ORDER_DELETE',          // source du mouvement
            '#CMD' . $commandeId     // référence
        );

        // Marquer la ligne comme annulée
        $pdo->prepare("
            UPDATE details_commandes
            SET annule = 1
            WHERE commande_id = :cid AND product_id = :pid
        ")->execute([
            'cid' => $commandeId,
            'pid' => $l['product_id']
        ]);
    }

    // 3️⃣ Supprimer LES DÉTAILS
    $pdo->prepare("
        DELETE FROM details_commandes
        WHERE commande_id = :id
    ")->execute(['id' => $commandeId]);

    // 4️⃣ Supprimer la commande
    $pdo->prepare("
        DELETE FROM commandes
        WHERE id = :id
    ")->execute(['id' => $commandeId]);

    $pdo->commit();

    echo "<p style='color:green;'>✅ Commande supprimée et stock recrédité.</p>";
    echo '<a href="index.php?r=sales_orders">⬅ Retour à la liste</a>';

} catch (Exception $e) {
    $pdo->rollBack();
    echo "<p style='color:red;'>❌ Erreur : " . $e->getMessage() . "</p>";
    echo '<a href="index.php?r=sales_orders">⬅ Retour</a>';
}
?>

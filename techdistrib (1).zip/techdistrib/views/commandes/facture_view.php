<?php
require __DIR__ . '/../../config/db.php';

/* ----------------------------------------------------
   1) Contrôle ID commande
---------------------------------------------------- */
if (!isset($_GET['id'])) {
    die("❌ Aucune commande sélectionnée !");
}
$id = (int) $_GET['id'];

/* ----------------------------------------------------
   2) Récupération commande + client
---------------------------------------------------- */
$sql = "SELECT commandes.*, clients.nom AS client_nom
        FROM commandes
        JOIN clients ON commandes.client_id = clients.id
        WHERE commandes.id = :id";

$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$commande = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$commande) {
    die("❌ Commande introuvable !");
}

/* ----------------------------------------------------
   3) Récupération des lignes de commande (nouvelle base)
---------------------------------------------------- */
$sql = "SELECT 
            d.id AS detail_id,
            p.name AS nom,
            d.quantite,
            d.prix_unitaire,
            d.annule
        FROM details_commandes d
        JOIN products p ON d.product_id = p.id
        WHERE d.commande_id = :id";

$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$details = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ----------------------------------------------------
   4) Calcul total réel non annulé
---------------------------------------------------- */
$total = 0;
foreach ($details as $d) {
    if ($d['annule'] == 0) {
        $total += $d['quantite'] * $d['prix_unitaire'];
    }
}
?>

<h2>Facture commande #<?php echo $id; ?></h2>
<p>Client : <strong><?php echo htmlspecialchars($commande['client_nom']); ?></strong></p>

<table border="1" cellpadding="5">
<tr>
    <th>Produit</th>
    <th>Quantité</th>
    <th>Prix (€)</th>
    <th>Total ligne (€)</th>
    <th>Statut</th>
    <th>Action</th>
</tr>

<?php foreach ($details as $d): 
    $ligneTotal = $d['quantite'] * $d['prix_unitaire'];
    $statut = $d['annule'] ? "❌ Annulé" : "🟢 Actif";
?>
<tr <?php echo $d['annule'] ? "style='color:gray;text-decoration:line-through;'" : ""; ?>>
    <td><?php echo htmlspecialchars($d['nom']); ?></td>
    <td><?php echo $d['quantite']; ?></td>
    <td><?php echo number_format($d['prix_unitaire'], 2, ',', ' '); ?> €</td>
    <td><?php echo number_format($ligneTotal, 2, ',', ' '); ?> €</td>
    <td><?php echo $statut; ?></td>
    <td>
        <?php if ($d['annule'] == 0): ?>
            <a href="index.php?r=sales_order_cancel_product&detail_id=<?php echo $d['detail_id']; ?>&commande_id=<?php echo $id; ?>"
               onclick="return confirm('Annuler ce produit ?');">Annuler</a>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</table>

<h3>Total : <?php echo number_format($total, 2, ',', ' '); ?> €</h3>

<br><br>
<a href="index.php?r=sales_order_invoice&id=<?php echo $id; ?>" target="_blank">📄 Télécharger la facture PDF</a>
<br><br>
<a href="index.php?r=sales_orders">⬅ Retour</a>

<?php 
require __DIR__ . '/../../config/db.php';
?>

<h2>Ajouter une commande client</h2>

<form method="POST">

  <!-- Sélection du client -->
  <label>Client :</label><br>
  <select name="client_id" required>
    <option value="">-- Sélectionner un client --</option>
    <?php
    $clients = $pdo->query("SELECT id, nom FROM clients ORDER BY nom ASC")->fetchAll();
    foreach ($clients as $c) {
        echo "<option value='{$c['id']}'>".htmlspecialchars($c['nom'])."</option>";
    }
    ?>
  </select>
  <br><br>

  <!-- Date -->
  <label>Date :</label><br>
  <input type="date" name="date_commande" required><br><br>

  <!-- Statut -->
  <label>Statut :</label><br>
  <select name="statut">
    <option value="En attente">En attente</option>
    <option value="Payée">Payée</option>
    <option value="Annulée">Annulée</option>
  </select>
  <br><br>

  <h3>Produits</h3>

  <table border="1" cellpadding="5">
    <tr>
      <th></th>
      <th>Produit</th>
      <th>Stock (réel)</th>
      <th>Quantité</th>
    </tr>

    <?php
    // 🔥 TU UTILISES MAINTENANT LA TABLE products
    $sql = "
        SELECT p.id, p.name,
            COALESCE((SELECT SUM(qty_received) 
                      FROM purchase_order_items poi 
                      WHERE poi.product_id = p.id),0)
          -
            COALESCE((SELECT SUM(quantity) 
                      FROM stock_movements sm 
                      WHERE sm.product_id = p.id AND sm.type='OUT'),0)
          +
            COALESCE((SELECT SUM(quantity) 
                      FROM stock_movements sm2 
                      WHERE sm2.product_id = p.id AND sm2.type='ADJ'),0)
          AS stock_reel
        FROM products p
        ORDER BY p.name ASC
    ";

    $produits = $pdo->query($sql)->fetchAll();

    foreach ($produits as $p) {
        echo "
        <tr>
          <td><input type='checkbox' name='produits[{$p['id']}]' value='{$p['id']}'></td>
          <td>".htmlspecialchars($p['name'])."</td>
          <td>{$p['stock_reel']}</td>
          <td><input type='number' name='qte[{$p['id']}]' value='1' min='1'></td>
        </tr>
        ";
    }
    ?>
  </table>

  <br>
  <input type="submit" name="ajouter" value="Enregistrer">
</form>

<?php
// ---------------- TRAITEMENT -----------------------
if (isset($_POST['ajouter'])) {

    if (empty($_POST['produits'])) {
        echo "<p style='color:red;'>❌ Sélectionne au moins un produit !</p>";
        exit;
    }

    // 1) Créer la commande
    $stmt = $pdo->prepare("
        INSERT INTO commandes (client_id, date_commande, total, statut)
        VALUES (:cid, :date, 0, :statut)
    ");

    $stmt->execute([
        'cid' => $_POST['client_id'],
        'date' => $_POST['date_commande'],
        'statut' => $_POST['statut']
    ]);

    $idCommande = $pdo->lastInsertId();
    $total = 0;

    // 2) Ajouter les lignes
    foreach ($_POST['produits'] as $pid) {
        $qte = (int) $_POST['qte'][$pid];

        // ⚠️ TEMPORAIRE : prix_unitaire = 0 (sera relié ACHATS plus tard)
        $stmtp = $pdo->prepare("SELECT price FROM products WHERE id = ?");
        $stmtp->execute([$pid]);
        $prod = $stmtp->fetch();

        $prix = $prod['price'];


        $stmt = $pdo->prepare("
            INSERT INTO details_commandes (commande_id, product_id, quantite, prix_unitaire)
            VALUES (:cid, :pid, :qte, :prix)
        ");

        $stmt->execute([
            'cid' => $idCommande,
            'pid' => $pid,
            'qte' => $qte,
            'prix' => $prix
        ]);

        $total += $prix * $qte;
    }

    // 3) Mettre à jour total
    $pdo->prepare("UPDATE commandes SET total = :t WHERE id = :id")
        ->execute(['t' => $total, 'id' => $idCommande]);

    echo "<p style='color:green;'>✅ Commande ajoutée !</p>";
}
?>

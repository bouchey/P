<?php
require __DIR__ . '/../../config/db.php';

/* ----------------------------------------------------
   FONCTION : enlever accents
---------------------------------------------------- */
function sans_accents($str) {
    $str = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $str);
    return preg_replace('/[^A-Za-z0-9 \-\.]/', '', $str);
}

/* ----------------------------------------------------
   Vérification ID
---------------------------------------------------- */
if (!isset($_GET['id'])) {
    die("Aucune commande sélectionnée !");
}
$id = (int) $_GET['id'];

/* ----------------------------------------------------
   Infos commande + client
---------------------------------------------------- */
$sql = "SELECT c.*, cl.nom, cl.email, cl.telephone, cl.adresse
        FROM commandes c
        JOIN clients cl ON c.client_id = cl.id
        WHERE c.id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) {
    die("Commande introuvable !");
}

/* ----------------------------------------------------
   PDF
---------------------------------------------------- */
require __DIR__ . '/../../fpdf/fpdf.php';

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 11);

/* ----------------------------------------------------
   EN-TETE
---------------------------------------------------- */
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, sans_accents("TechDistrib SARL"), 0, 1, 'R');

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(0, 6, sans_accents("12 rue des Technologies, Lyon"), 0, 1, 'R');
$pdf->Cell(0, 6, sans_accents("Email : contact@techdistrib.fr"), 0, 1, 'R');
$pdf->Ln(10);

/* ----------------------------------------------------
   TITRE FACTURE
---------------------------------------------------- */
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, sans_accents("Facture n° ") . $data['id'], 0, 1, 'C');
$pdf->Ln(5);

/* ----------------------------------------------------
   INFOS CLIENT
---------------------------------------------------- */
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, sans_accents("Informations client :"), 0, 1);

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(100, 6, "Nom : " . sans_accents($data['nom']), 0, 1);
$pdf->Cell(100, 6, "Email : " . sans_accents($data['email']), 0, 1);
$pdf->Cell(100, 6, "Téléphone : " . sans_accents($data['telephone']), 0, 1);
$pdf->MultiCell(0, 6, "Adresse : " . sans_accents($data['adresse']));
$pdf->Ln(8);

/* ----------------------------------------------------
   TABLE PRODUITS
---------------------------------------------------- */
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(220, 220, 220);
$pdf->Cell(90, 8, sans_accents("Produit"), 1, 0, 'C', true);
$pdf->Cell(30, 8, "Quantité", 1, 0, 'C', true);
$pdf->Cell(35, 8, "Prix (€)", 1, 0, 'C', true);
$pdf->Cell(35, 8, "Total (€)", 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 11);

/* ----------------------------------------------------
   PRODUITS : nouvelle jointure avec products
---------------------------------------------------- */
$sql = "SELECT p.name, d.quantite, d.prix_unitaire, d.annule
        FROM details_commandes d
        JOIN products p ON d.product_id = p.id
        WHERE d.commande_id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$produits = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = 0;

/* ----------------------------------------------------
   LIGNES
---------------------------------------------------- */
foreach ($produits as $item) {
    $nom_produit = sans_accents($item['name']);
    $totalLigne = $item['quantite'] * $item['prix_unitaire'];

    if ($item['annule']) {
        $pdf->SetTextColor(150, 0, 0);
        $pdf->SetFont('Arial', 'I', 11);
        $pdf->Cell(90, 8, $nom_produit . " (ANNULÉ)", 1);
    } else {
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(90, 8, $nom_produit, 1);

        $total += $totalLigne;
    }

    $pdf->Cell(30, 8, $item['quantite'], 1, 0, 'C');
    $pdf->Cell(35, 8, number_format($item['prix_unitaire'], 2, ',', ' '), 1, 0, 'R');
    $pdf->Cell(35, 8, number_format($totalLigne, 2, ',', ' '), 1, 1, 'R');
}

/* ----------------------------------------------------
   TOTAL
---------------------------------------------------- */
$pdf->Ln(5);
$pdf->SetFont('Arial', 'B', 13);
$pdf->Cell(155, 10, sans_accents("TOTAL À PAYER"), 1, 0, 'R');
$pdf->Cell(35, 10, number_format($total, 2, ',', ' ') . " €", 1, 1, 'R');

/* ----------------------------------------------------
   STATUT
---------------------------------------------------- */
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, "Statut : " . sans_accents($data['statut']), 0, 1);

/* ----------------------------------------------------
   PIED
---------------------------------------------------- */
$pdf->SetFont('Arial', 'I', 10);
$pdf->Ln(5);
$pdf->Cell(0, 6, "Produits annulés non facturés.", 0, 1, 'C');
$pdf->Cell(0, 6, "Merci pour votre confiance !", 0, 1, 'C');

/* ----------------------------------------------------
   SORTIE
---------------------------------------------------- */
$pdf->Output('I', 'Facture_'.$data['id'].'.pdf');
exit;

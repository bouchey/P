<?php
require __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/stock.php';

if (!isset($_GET['detail_id']) || !isset($_GET['commande_id'])) {
    die("❌ Paramètres manquants.");
}

$detailId = (int) $_GET['detail_id'];
$commandeId = (int) $_GET['commande_id'];

// 1. Récupérer la ligne de commande
$stmt = $pdo->prepare("
    SELECT product_id, quantite, prix_unitaire, annule
    FROM details_commandes
    WHERE id = :id
");
$stmt->execute(['id' => $detailId]);
$detail = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$detail) {
    die("❌ Ligne de commande introuvable.");
}

// Si déjà annulé → retourner
if ($detail['annule']) {
    header("Location: index.php?r=sales_order_invoice_view&id=$commandeId");
    exit;
}

try {
    $pdo->beginTransaction();

    // 2. Marquer comme annulé
    $pdo->prepare("
        UPDATE details_commandes
        SET annule = 1
        WHERE id = :id
    ")->execute(['id' => $detailId]);

    // 3. Ajouter un mouvement de stock (IN)
    stock_add_movement(
    $pdo,
    $detail['product_id'],
    'IN',
    $detail['quantite'],
    'SALE_CANCEL',
    '#CMD' . $commandeId
);


    // 4. Recalculer le total
    $stmt = $pdo->prepare("
        SELECT SUM(quantite * prix_unitaire)
        FROM details_commandes
        WHERE commande_id = :cid
        AND annule = 0
    ");
    $stmt->execute(['cid' => $commandeId]);
    $newTotal = $stmt->fetchColumn() ?? 0;

    $pdo->prepare("
        UPDATE commandes
        SET total = :t
        WHERE id = :id
    ")->execute([
        't' => $newTotal,
        'id' => $commandeId
    ]);

    $pdo->commit();

} catch (Exception $e) {
    $pdo->rollBack();
    die("❌ Erreur : " . $e->getMessage());
}

// Retour facture
header("Location: index.php?r=sales_order_invoice_view&id=$commandeId");
exit;
?>

<?php
// Traitement du formulaire
$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pid   = (int)($_POST['product_id'] ?? 0);
    $dir   = $_POST['direction'] ?? 'PLUS';
    $qty   = max(0, (int)($_POST['qty'] ?? 0));
    $motif = trim($_POST['reason'] ?? '');

    if ($pid <= 0 || $qty <= 0) {
        $message = "Sélectionne un produit et une quantité > 0.";
    } else {
        $signedQty = ($dir === 'MOINS') ? -$qty : $qty;

        $st = $pdo->prepare("
            INSERT INTO stock_movements(product_id,type,quantity,source,ref_id)
            VALUES(?,?,?,?,?)
        ");

        $st->execute([
            $pid,
            'ADJ',
            $signedQty,
            'ADJUST',
            mb_substr($motif ?: ($dir === 'MOINS' ? 'Ajustement -' : 'Ajustement +'), 0, 60)
        ]);

        $message = "Ajustement enregistré.";
    }
}

// Liste des produits
$products = $pdo->query("SELECT id,sku,name FROM products ORDER BY name")->fetchAll();

// Derniers ajustements
$st = $pdo->prepare("
    SELECT sm.*, p.sku, p.name
    FROM stock_movements sm
    JOIN products p ON p.id = sm.product_id
    WHERE sm.type = 'ADJ'
    ORDER BY sm.movement_date DESC, sm.id DESC
    LIMIT 10
");
$st->execute();
$lastAdj = $st->fetchAll();
?>

<h2>Ajustement de stock</h2>

<?php if ($message): ?>
  <div class="alert"><?=h($message)?></div>
<?php endif; ?>

<form method="post">
  <label>Produit</label>
  <select name="product_id" required>
    <option value="">—</option>
    <?php foreach($products as $p): ?>
      <option value="<?=$p['id']?>"><?=h($p['sku'].' - '.$p['name'])?></option>
    <?php endforeach; ?>
  </select>

  <label>Type d’ajustement</label>
  <select name="direction">
    <option value="PLUS">+ Ajouter au stock</option>
    <option value="MOINS">− Retirer du stock</option>
  </select>

  <label>Quantité</label>
  <input type="number" name="qty" min="1" value="1">

  <label>Motif</label>
  <input type="text" name="reason" placeholder="Inventaire, casse, erreur…">

  <button class="btn">Valider l’ajustement</button>
  <a class="btn secondary" href="index.php?r=stock">Retour aux alertes</a>
</form>

<?php if ($lastAdj): ?>
  <h3>Derniers ajustements</h3>
  <table>
    <tr><th>Date</th><th>Produit</th><th>Qté</th><th>Motif</th></tr>
    <?php foreach($lastAdj as $a): ?>
      <tr>
        <td><?=h($a['movement_date'])?></td>
        <td><?=h($a['sku'].' - '.$a['name'])?></td>
        <td style="color:<?=($a['quantity'] < 0 ? 'red' : 'green')?>;">
          <?=$a['quantity']?>
        </td>
        <td><?=h($a['ref_id'])?></td>
      </tr>
    <?php endforeach; ?>
  </table>
<?php endif; ?>

</main>
<footer class="foot">PGI • Projet SI</footer>
</body></html>

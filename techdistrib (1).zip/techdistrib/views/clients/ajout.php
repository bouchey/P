<?php
// --- Connexion BDD ---
require __DIR__ . '/../../config/db.php';

// --- Header commun ---

// Initialisation message
$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = $_POST["nom"] ?? "";
    $email = $_POST["email"] ?? "";
    $telephone = $_POST["telephone"] ?? "";
    $adresse = $_POST["adresse"] ?? "";

    if (!empty($nom)) {
        $stmt = $pdo->prepare("INSERT INTO clients (nom, email, telephone, adresse) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$nom, $email, $telephone, $adresse])) {
            $message = "✅ Client ajouté avec succès !";
        } else {
            $message = "❌ Erreur : Impossible d'ajouter le client.";
        }
    } else {
        $message = "⚠️ Le nom du client est obligatoire.";
    }
}
?>

<h2>Ajouter un client</h2>

<?php if ($message): ?>
    <p><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<form method="POST">
    <label>Nom :</label>
    <input type="text" name="nom" required>

    <label>Email :</label>
    <input type="email" name="email">

    <label>Téléphone :</label>
    <input type="text" name="telephone">

    <label>Adresse :</label>
    <textarea name="adresse"></textarea>

    <button type="submit">Enregistrer</button>
</form>



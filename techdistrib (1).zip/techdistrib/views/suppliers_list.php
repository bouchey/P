<?php

// Suppression sécurisée
if (isset($_POST['delete_id'])) {

    $id = (int) $_POST['delete_id'];

    // Vérifier si fournisseur utilisé dans des bons d’achat
    $stCheck = $pdo->prepare("
        SELECT COUNT(*) 
        FROM purchase_orders 
        WHERE supplier_id = ?
    ");
    $stCheck->execute([$id]);

    if ($stCheck->fetchColumn() > 0) {
        die("<p style='color:red'>Impossible de supprimer : fournisseur utilisé dans des achats.</p>");
    }

    // OK : supprimer
    $st = $pdo->prepare("DELETE FROM suppliers WHERE id=?");
    $st->execute([$id]);
}

// Récupérer fournisseurs avec nombre de PO
$sql = "
    SELECT s.*,
    (SELECT COUNT(*) FROM purchase_orders WHERE supplier_id = s.id) AS po_count
    FROM suppliers s
    ORDER BY created_at DESC
";

$sup = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>

<h2>Fournisseurs</h2>

<p>
    <a class="btn" href="index.php?r=supplier_form">+ Nouveau fournisseur</a>
</p>

<table>
  <tr>
    <th>Nom</th>
    <th>Email</th>
    <th>Téléphone</th>
    <th>Conditions</th>
    <th>Achats</th>
    <th>Actions</th>
  </tr>

  <?php foreach($sup as $s): ?>
  <tr>
    <td><?= h($s['name']) ?></td>
    <td><?= h($s['email']) ?></td>
    <td><?= h($s['phone']) ?></td>
    <td><?= h($s['payment_terms']) ?></td>

    <td>
        <?php if ($s['po_count'] > 0): ?>
            <a href="index.php?r=po&supplier_id=<?= $s['id'] ?>">
                <?= $s['po_count'] ?> bon(s) d’achat
            </a>
        <?php else: ?>
            Aucun
        <?php endif; ?>
    </td>

    <td class="actions">
      <a class="btn secondary" href="index.php?r=supplier_form&id=<?= $s['id'] ?>">Éditer</a>

      <form method="post" style="display:inline" 
            onsubmit="return confirm('Supprimer ce fournisseur ?')">
        <input type="hidden" name="delete_id" value="<?= $s['id'] ?>">
        <button class="btn" style="background:#b91c1c">Supprimer</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>

</table>

<?php
// Suppression employé
if (isset($_POST['delete_id'])) {
    $st = $pdo->prepare("DELETE FROM employees WHERE id=?");
    $st->execute([(int)$_POST['delete_id']]);
}

// Récupérer liste employés
$rows = $pdo->query("
    SELECT id, first_name, last_name, role, email, phone
    FROM employees
    ORDER BY id DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<h2>Employés</h2>

<p><a class="btn" href="index.php?r=employee_form">+ Nouvel employé</a></p>

<table>
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Rôle</th>
        <th>Email</th>
        <th>Téléphone</th>
        <th>Actions</th>
    </tr>

    <?php foreach($rows as $e): ?>
    <tr>
        <td><?= h($e['last_name']) ?></td>
        <td><?= h($e['first_name']) ?></td>
        <td><?= h($e['role']) ?></td>
        <td><?= h($e['email']) ?></td>
        <td><?= h($e['phone']) ?></td>

        <td class="actions">
            <a class="btn secondary" href="index.php?r=employee_form&id=<?= $e['id'] ?>">Éditer</a>

            <form method="post" style="display:inline" onsubmit="return confirm('Supprimer ?');">
                <input type="hidden" name="delete_id" value="<?= $e['id'] ?>">
                <button class="btn" style="background:#b91c1c">Supprimer</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

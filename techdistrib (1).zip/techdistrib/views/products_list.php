<?php


/* ============================
   SUPPRESSION PRODUIT
============================ */
if (isset($_POST['delete_id'])) {

    $pid = (int) $_POST['delete_id'];

    // Vérifier si le produit est utilisé
    $in_orders = $pdo->prepare("SELECT COUNT(*) FROM details_commandes WHERE product_id = ?");
    $in_orders->execute([$pid]);

    if ($in_orders->fetchColumn() > 0) {
        die("<p style='color:red'>Impossible de supprimer : produit utilisé dans des commandes.</p>");
    }

    // Vérifier si utilisé dans des achats
    $in_pos = $pdo->prepare("SELECT COUNT(*) FROM purchase_order_items WHERE product_id = ?");
    $in_pos->execute([$pid]);

    if ($in_pos->fetchColumn() > 0) {
        die("<p style='color:red'>Impossible supprimer : produit utilisé dans des bons d’achat.</p>");
    }

    // Supprimer mouvements stock
    $pdo->prepare("DELETE FROM stock_movements WHERE product_id = ?")->execute([$pid]);

    // Supprimer produit
    $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$pid]);
}

/* ============================
   RÉCUPÉRATION PRODUITS + STOCK
============================ */
$sql = "
    SELECT p.id, p.sku, p.name, p.category, p.price, p.reorder_level,
           COALESCE(SUM(
                CASE 
                    WHEN m.type='IN' THEN m.quantity
                    WHEN m.type='OUT' THEN -m.quantity
                    WHEN m.type='ADJ' THEN m.quantity
                    ELSE 0
                END
           ),0) AS stock_qty
    FROM products p
    LEFT JOIN stock_movements m ON m.product_id = p.id
    GROUP BY p.id
    ORDER BY p.created_at DESC
";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Produits</h2>
<p><a class="btn" href="index.php?r=product_form">+ Ajouter un produit</a></p>

<table>
<tr>
    <th>SKU</th>
    <th>Nom</th>
    <th>Catégorie</th>
    <th>Prix (€)</th>
    <th>Seuil</th>
    <th>Stock</th>
    <th>Status</th>
    <th>Actions</th>
</tr>

<?php foreach ($rows as $p): ?>

<tr>
    <td><?= h($p['sku']) ?></td>
    <td><?= h($p['name']) ?></td>
    <td><?= h($p['category']) ?></td>
    <td><?= number_format($p['price'], 2, ',', ' ') ?> €</td>
    <td><?= h($p['reorder_level']) ?></td>

    <!-- Stock -->
    <td><?= $p['stock_qty'] ?></td>

    <!-- Alerte stock -->
    <td>
        <?php if ($p['stock_qty'] < $p['reorder_level']): ?>
            <span style="color:red;font-weight:bold">⚠ Rupture</span>
        <?php else: ?>
            <span style="color:green">OK</span>
        <?php endif; ?>
    </td>

    <td>
        <a class="btn secondary" href="index.php?r=product_form&id=<?= $p['id'] ?>">Éditer</a>

        <!-- Voir mouvements stock -->
        <a class="btn" href="index.php?r=stock&product_id=<?= $p['id'] ?>">Stock</a>

        <!-- Voir PO -->
        <a class="btn" href="index.php?r=po&product_id=<?= $p['id'] ?>">Achats</a>

        <form method="post" style="display:inline" onsubmit="return confirm('Supprimer ce produit ?')">
            <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
            <button class="btn" style="background:#b91c1c">Supprimer</button>
        </form>
    </td>
</tr>

<?php endforeach; ?>
</table>

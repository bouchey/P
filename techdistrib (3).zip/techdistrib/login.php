<?php
session_start();
require __DIR__."/config/db.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = $_POST["username"] ?? "";
    $password = $_POST["password"] ?? "";

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $u = $stmt->fetch();

    if ($u && hash("sha256", $password) === $u["password_hash"]) {
        $_SESSION["user_id"] = $u["id"];
        $_SESSION["username"] = $u["username"];
        $_SESSION["role"] = $u["role"];

        header("Location: index.php");
        exit;
    } else {
        $error = "Nom d'utilisateur ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Connexion</title>
<style>
body{font-family:Arial;background:#f5f5f5;padding:40px;}
.login-box{width:350px;margin:auto;background:white;padding:20px;border-radius:8px;box-shadow:0 4px 15px rgba(0,0,0,0.1);}
input{width:100%;padding:10px;margin:8px 0;border:1px solid #ccc;border-radius:5px;}
button{background:#1f9d78;color:white;padding:10px;width:100%;border:none;border-radius:5px;cursor:pointer;}
.error{color:red;margin-top:10px;}
</style>
</head>
<body>

<div class="login-box">
<h2>Connexion</h2>
<form method="POST">
    <input type="text" name="username" placeholder="Nom d'utilisateur" required>
    <input type="password" name="password" placeholder="Mot de passe" required>
    <button type="submit">Se connecter</button>
</form>

<?php if($error): ?>
<p class="error"><?= $error ?></p>
<?php endif; ?>

</div>

</body>
</html>

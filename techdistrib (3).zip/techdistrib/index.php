<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__."/config/db.php";
require __DIR__."/lib/helpers.php";
require __DIR__."/lib/stock.php"; 
require __DIR__ . "/lib/auth.php";


$route = $_GET['r'] ?? 'home';

/* Autoriser la page login sans blocage */
if ($route === "login") {
    require __DIR__."/login.php";
    exit;
}

/* Bloquer toutes les pages si pas connecté */
require_login();

ob_start();

switch ($route) {

    /* === MODULE CLIENTS (Binôme) === */
    case 'customers':
        require __DIR__."/views/clients/liste.php";
        break;

    case 'customer_form':
        require __DIR__."/views/clients/ajout.php";
        break;

    case 'customer_edit':
        require __DIR__."/views/clients/modifier.php";
        break;

    case 'customer_delete':
        require __DIR__."/views/clients/supprimer.php";
        break;

    case 'customer_fiche':
        require __DIR__."/views/clients/fiche.php";
        break;

    case 'customer_pdf':
        require __DIR__."/views/clients/fiche_pdf.php";
        break;


    /* === COMMANDES CLIENTS (Binôme) === */
    case 'sales_orders':
        require __DIR__."/views/commandes/liste.php";
        break;

    case 'sales_order_form':
        require __DIR__."/views/commandes/ajout.php";
        break;

    case 'sales_order_edit':
        require __DIR__."/views/commandes/modifier.php";
        break;

    case 'sales_order_delete':
        require __DIR__."/views/commandes/supprimer.php";
        break;

    case 'sales_order_edit_lines':
        require __DIR__."/views/commandes/modifier_details.php";
        break;

    case 'sales_order_cancel_product':
        require __DIR__."/views/commandes/annuler_produit.php";
        break;

    case 'sales_order_invoice':
        require __DIR__."/views/commandes/facture.php";
        break;

    case 'sales_order_invoice_view':
        require __DIR__."/views/commandes/facture_view.php";
        break;
    case 'sales_order_invoice_list':
        require __DIR__."/views/commandes/facture_list.php";
        break;
    


    /* === MODULE PRODUITS (Binôme) === */
    case 'products_binome':
        require __DIR__."/views/produits/liste.php";
        break;

    case 'product_binome_form':
        require __DIR__."/views/produits/ajout.php";
        break;

    case 'product_binome_edit':
        require __DIR__."/views/produits/modifier.php";
        break;

    case 'product_binome_delete':
        require __DIR__."/views/produits/supprimer.php";
        break;


    /* === PRODUITS (Toi) === */
    case 'products':
        require __DIR__."/views/products_list.php";
        break;

    case 'product_form':
        require __DIR__."/views/product_form.php";
        break;


    /* === ACHATS — Commandes Fournisseurs (Toi) === */
    case 'po':
        require __DIR__."/views/po_list.php";
        break;

    case 'po_form':
        require __DIR__."/views/po_form.php";
        break;

    case 'po_receive':
        require __DIR__."/views/po_receive.php";
        break;


    /* === FOURNISSEURS (Toi) === */
    case 'suppliers':
        require __DIR__."/views/suppliers_list.php";
        break;

    case 'supplier_form':
        require __DIR__."/views/supplier_form.php";
        break;


    /* === STOCKS (Toi) === */
    case 'stock':
        require __DIR__."/views/stock_dashboard.php";
        break;

    case 'stock_all':
        require __DIR__."/views/stock_all.php";
        break;

    case 'stock_out':
        require __DIR__."/views/stock_out.php";
        break;

    case 'stock_adjust':
        require __DIR__."/views/stock_adjust.php";
        break;


    /* === EMPLOYÉS (Toi) === */
    case 'employees':
        require __DIR__."/views/employees_list.php";
        break;

    case 'employee_form':
        require __DIR__."/views/employee_form.php";
        break;


    /* === PAGE D’ACCUEIL === */
    default:
        require __DIR__."/views/home.php";
        break;
}

$content = ob_get_clean();
include __DIR__."/views/_layout_header.php";
echo $content;
include __DIR__."/views/_layout_footer.php";

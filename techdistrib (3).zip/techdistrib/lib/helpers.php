<?php
function redirect($r){ header("Location: index.php?r=$r"); exit; }
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

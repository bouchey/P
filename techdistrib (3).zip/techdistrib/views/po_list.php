<?php

// Filtrage par fournisseur (optionnel)
$supplier_id = (int)($_GET['supplier_id'] ?? 0);

if ($supplier_id) {
    $sql = "
        SELECT po.*, s.name supplier,
        (SELECT COUNT(*) FROM purchase_order_items WHERE purchase_order_id = po.id) AS items_count
        FROM purchase_orders po
        JOIN suppliers s ON s.id = po.supplier_id
        WHERE po.supplier_id = ?
        ORDER BY po.order_date DESC
    ";
    $st = $pdo->prepare($sql);
    $st->execute([$supplier_id]);
    $pos = $st->fetchAll(PDO::FETCH_ASSOC);
} else {
    $pos = $pdo->query("
        SELECT po.*, s.name supplier,
        (SELECT COUNT(*) FROM purchase_order_items WHERE purchase_order_id = po.id) AS items_count
        FROM purchase_orders po
        JOIN suppliers s ON s.id = po.supplier_id
        ORDER BY po.order_date DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
}

?>

<h2>Commandes d’achat</h2>

<p><a class="btn" href="index.php?r=po_form">+ Nouvelle commande</a></p>

<table>
<tr>
  <th>#</th>
  <th>Fournisseur</th>
  <th>Date</th>
  <th>Articles</th>
  <th>Statut</th>
  <th>Actions</th>
</tr>

<?php foreach ($pos as $po): ?>

<tr>
  <td><?= h($po['id']) ?></td>
  <td><?= h($po['supplier']) ?></td>
  <td><?= h($po['order_date']) ?></td>

  <td><?= $po['items_count'] ?> article(s)</td>

  <td>
    <?php if ($po['status'] === 'DRAFT'): ?>
      <span style="color:gray">Brouillon</span>

    <?php elseif ($po['status'] === 'SENT'): ?>
      <span style="color:orange">Envoyé</span>

    <?php elseif ($po['status'] === 'RECEIVED_PART'): ?>
      <span style="color:#eab308">Reçu partiellement</span>

    <?php elseif ($po['status'] === 'RECEIVED_ALL'): ?>
      <span style="color:green;font-weight:bold">Reçu</span>

    <?php endif; ?>
  </td>

  <td class="actions">
    <a class="btn secondary" href="index.php?r=po_form&id=<?= $po['id'] ?>">Éditer</a>
    <a class="btn" href="index.php?r=po_receive&id=<?= $po['id'] ?>">Réception</a>
  </td>
</tr>

<?php endforeach; ?>

</table>

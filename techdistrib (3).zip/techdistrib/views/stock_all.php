<?php
$rows = stock_levels($pdo);
?>

<h2>Inventaire – Stock complet</h2>

<p>
  <a class="btn" href="index.php?r=stock_out">+ Sortie de stock</a>
  <a class="btn secondary" href="index.php?r=stock_adjust">Ajustement</a>
</p>

<table>
  <tr>
    <th>SKU</th>
    <th>Produit</th>
    <th>Seuil</th>
    <th>Stock actuel</th>
  </tr>

  <?php foreach ($rows as $p): ?>
    <tr>
      <td><?= h($p['sku']) ?></td>
      <td><?= h($p['name']) ?></td>
      <td><?= h($p['reorder_level']) ?></td>

      <td style="color:<?= ($p['stock_qty'] < $p['reorder_level']) ? 'red' : 'black' ?>;">
        <?= h($p['stock_qty']) ?>
      </td>
    </tr>
  <?php endforeach; ?>

</table>

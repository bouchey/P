<?php
// === INCLUDES CORRIGÉS SEULEMENT ===
require __DIR__ . '/../../config/db.php';
require __DIR__ . '/../_layout_header.php';

// Vérifier l'ID
if (!isset($_GET['id'])) {
    die("❌ Client introuvable.");
}

$id = $_GET['id'];

// Infos du client
$stmt = $pdo->prepare("SELECT * FROM clients WHERE id = :id");
$stmt->execute(['id' => $id]);
$client = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$client) {
    die("❌ Client introuvable.");
}

// Récupération des commandes du client
$stmt2 = $pdo->prepare("SELECT * FROM commandes WHERE client_id = :id");
$stmt2->execute(['id' => $id]);
$commandes = $stmt2->fetchAll(PDO::FETCH_ASSOC);

// Calcul du total dépensé
$totalDepense = 0;
foreach ($commandes as $cmd) {
    $totalDepense += $cmd['total'];
}
?>

<h2>Fiche du client : <?= htmlspecialchars($client['nom']) ?></h2>

<p><strong>Email :</strong> <?= htmlspecialchars($client['email']) ?></p>
<p><strong>Téléphone :</strong> <?= htmlspecialchars($client['telephone']) ?></p>
<p><strong>Adresse :</strong> <?= nl2br(htmlspecialchars($client['adresse'])) ?></p>

<hr>

<h3>Commandes du client :</h3>

<table border="1" cellpadding="7">
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Statut</th>
        <th>Total</th>
    </tr>

    <?php foreach ($commandes as $cmd): ?>
    <tr>
        <td><?= $cmd['id'] ?></td>
        <td><?= $cmd['date_commande'] ?></td>
        <td><?= htmlspecialchars($cmd['statut']) ?></td>
        <td><?= number_format($cmd['total'], 2, ',', ' ') ?> €</td>
    </tr>
    <?php endforeach; ?>
</table>

<h3>Total dépensé : 
  <span style="color:blue;">
    <?= number_format($totalDepense, 2, ',', ' ') ?> €
  </span>
</h3>

<br><br>

<a href="fiche_pdf.php?id=<?= $id ?>" target="_blank">📄 Télécharger la fiche client (PDF)</a>
<br><br>
<a href="liste.php">⬅ Retour à la liste</a>

<?php require __DIR__ . '/../_layout_footer.php'; ?>

<?php
// === includes corrigés SEULEMENT ===

// Connexion BDD
require __DIR__ . '/../../config/db.php';

// Définition du chemin des polices FPDF (inchangé)
define('FPDF_FONTPATH', __DIR__ . '/../../fpdf/font/');

// Inclusion de FPDF
require __DIR__ . '/../../fpdf/fpdf.php';

/* ---------------------------------------------------------
   Fonction : supprimer tous les accents
--------------------------------------------------------- */
function sansAccents($str) {
    $accents = array(
        'À'=>'A','Á'=>'A','Â'=>'A','Ã'=>'A','Ä'=>'A','Å'=>'A','à'=>'a','á'=>'a','â'=>'a','ã'=>'a','ä'=>'a','å'=>'a',
        'È'=>'E','É'=>'E','Ê'=>'E','Ë'=>'E','è'=>'e','é'=>'e','ê'=>'e','ë'=>'e',
        'Ì'=>'I','Í'=>'I','Î'=>'I','Ï'=>'I','ì'=>'i','í'=>'i','î'=>'i','ï'=>'i',
        'Ò'=>'O','Ó'=>'O','Ô'=>'O','Õ'=>'O','Ö'=>'O','Ø'=>'O','ò'=>'o','ó'=>'o','ô'=>'o','õ'=>'o','ö'=>'o','ø'=>'o',
        'Ù'=>'U','Ú'=>'U','Û'=>'U','Ü'=>'U','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u',
        'Ç'=>'C','ç'=>'c','Ñ'=>'N','ñ'=>'n','Ý'=>'Y','ý'=>'y','ÿ'=>'y'
    );
    return strtr($str, $accents);
}

/* ---------------------------------------------------------
   RECUPERATION DU CLIENT
--------------------------------------------------------- */
$id = $_GET['id'];

$req = $pdo->prepare("SELECT * FROM clients WHERE id = ?");
$req->execute([$id]);
$client = $req->fetch();

if (!$client) {
    die("Client introuvable");
}

/* ---------------------------------------------------------
   RECUPERATION DES COMMANDES DU CLIENT
--------------------------------------------------------- */
$sql = "SELECT * FROM commandes WHERE client_id = ?";
$stm = $pdo->prepare($sql);
$stm->execute([$id]);
$commandes = $stm->fetchAll();

/* ---------------------------------------------------------
   Création du PDF
--------------------------------------------------------- */
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,sansAccents("Fiche du client"),0,1,'C');
$pdf->Ln(5);

$pdf->SetFont('Arial','',12);
$pdf->Cell(40,7,"Nom : ",0,0);
$pdf->Cell(100,7,sansAccents($client['nom']),0,1);

$pdf->Cell(40,7,"Email : ",0,0);
$pdf->Cell(100,7,sansAccents($client['email']),0,1);

$pdf->Cell(40,7,"Telephone : ",0,0);
$pdf->Cell(100,7,sansAccents($client['telephone']),0,1);

$pdf->Ln(4);
$pdf->MultiCell(0,7,"Adresse : ".sansAccents($client['adresse']),0,1);

$pdf->Ln(10);
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,sansAccents("Commandes du client"),0,1);
$pdf->Ln(5);

/* ---------------------------------------------------------
   TABLEAU DES COMMANDES
--------------------------------------------------------- */
$pdf->SetFont('Arial','B',12);
$pdf->Cell(40,8,"ID Commande",1);
$pdf->Cell(60,8,"Date",1);
$pdf->Cell(40,8,"Statut",1);
$pdf->Cell(40,8,"Total",1);
$pdf->Ln();

$pdf->SetFont('Arial','',12);

$totalDepense = 0;

foreach ($commandes as $cmd) {
    $pdf->Cell(40,8,$cmd['id'],1);
    $pdf->Cell(60,8,$cmd['date_commande'],1);
    $pdf->Cell(40,8,sansAccents($cmd['statut']),1);
    $pdf->Cell(40,8,number_format($cmd['total'],2,',',' '),1);
    $pdf->Ln();

    $totalDepense += $cmd['total'];
}

/* ---------------------------------------------------------
   TOTAL DEPENSE
--------------------------------------------------------- */
$pdf->Ln(10);
$pdf->SetFont('Arial','B',12);
$pdf->SetTextColor(0,0,150);
$pdf->Cell(0,10,sansAccents("TOTAL DEPENSE : ").number_format($totalDepense,2,',',' ')." euro",0,1,'C');

/* ---------------------------------------------------------
   Sortie PDF
--------------------------------------------------------- */
$pdf->Output("I","Fiche_Client_".$client['id'].".pdf");

?>

<?php
require __DIR__ . '/../../config/db.php';
require __DIR__ . '/../_layout_header.php';

// Vérifie qu'on a bien un ID dans l'URL
if (!isset($_GET['id'])) {
    die("❌ Aucun client sélectionné.");
}

$id = $_GET['id'];

// Supprime le client correspondant
$stmt = $pdo->prepare("DELETE FROM clients WHERE id = :id");
$stmt->execute(['id' => $id]);

echo "<p style='color:red;'>🗑️ Client supprimé avec succès !</p>";
echo "<a href='liste.php'>⬅ Retour à la liste</a>";
?>

<?php require __DIR__ . '/../_layout_footer.php'; ?>

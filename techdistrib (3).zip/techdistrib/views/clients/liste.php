<?php
require __DIR__ . '/../../config/db.php';
?>

<h2>Liste des clients</h2>

<!-- Lien pour ajouter un client -->
<a href="/techdistrib/views/clients/ajout.php">+ Ajouter un client</a>

<table border="1" cellpadding="5">
  <tr>
    <th>ID</th>
    <th>Nom</th>
    <th>Email</th>
    <th>Téléphone</th>
    <th>Adresse</th>
    <th>Actions</th>
  </tr>

<?php
$stmt = $pdo->query("SELECT * FROM clients ORDER BY nom ASC");

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

  echo "<tr>";
  
  echo "<td>{$row['id']}</td>";
  echo "<td>" . htmlspecialchars($row['nom']) . "</td>";
  echo "<td>{$row['email']}</td>";
  echo "<td>{$row['telephone']}</td>";
  echo "<td>" . htmlspecialchars($row['adresse']) . "</td>";

  echo "<td>
          <a href='/techdistrib/views/clients/fiche.php?id={$row['id']}'>📄 Fiche client</a> |
          <a href='/techdistrib/views/clients/modifier.php?id={$row['id']}'>✏️ Modifier</a> |
          <a href='/techdistrib/views/clients/supprimer.php?id={$row['id']}' onclick=\"return confirm('Supprimer ce client ?');\">🗑️ Supprimer</a>
        </td>";

  echo "</tr>";
}
?>
</table>


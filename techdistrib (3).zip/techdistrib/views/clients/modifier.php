<?php
// Correction des includes : on remonte de 2 niveaux pour atteindre /config.php
require __DIR__ . '/../../config.php';

$id = $_GET['id'];
$clients = $pdo->prepare("SELECT * FROM clients WHERE id=?");
$clients->execute([$id]);
$client = $clients->fetch();

if (!$client) {
    die("Client introuvable.");
}

if (isset($_POST['submit'])) {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $adresse = $_POST['adresse'];

    $update = $pdo->prepare("UPDATE clients SET nom=?, email=?, telephone=?, adresse=? WHERE id=?");
    $update->execute([$nom, $email, $telephone, $adresse, $id]);

    header("Location: liste.php");
    exit;
}

?>

<?php include __DIR__ . '/../../_layout_header.php'; ?>

<h2>Modifier un client</h2>

<form method="POST">
    <label>Nom :</label>
    <input type="text" name="nom" value="<?= $client['nom']; ?>" required>

    <label>Email :</label>
    <input type="email" name="email" value="<?= $client['email']; ?>">

    <label>Téléphone :</label>
    <input type="text" name="telephone" value="<?= $client['telephone']; ?>">

    <label>Adresse :</label>
    <textarea name="adresse"><?= $client['adresse']; ?></textarea>

    <button type="submit" name="submit">Mettre à jour</button>
</form>

<a href="liste.php" class="btn">Retour</a>

<?php include __DIR__ . '/../../_layout_footer.php'; ?>

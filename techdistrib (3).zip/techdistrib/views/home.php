<div class="home-banner">
    <img src="public/img/Accueil.jpg" alt="Accueil TechDistrib">
</div>

<h2>BienvenueBienvenue sur TechDistrib</h2>
<p>un projet PGI conçu pour gérer les ventes, les achats, les stocks, les fournisseurs et les employés d’une entreprise.</p>

<?php

// Soumission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $pid = (int)($_POST['product_id'] ?? 0);
    $qty = max(0, (int)($_POST['qty'] ?? 0));
    $ref = trim($_POST['ref'] ?? 'web');

    if ($pid > 0 && $qty > 0) {

        // Vérifier que le produit existe
        $st = $pdo->prepare("SELECT id FROM products WHERE id=?");
        $st->execute([$pid]);
        if (!$st->fetchColumn()) {
            echo '<div class="alert">Produit inexistant.</div>';
        } else {

            // Vérifier stock dispo
            $st = $pdo->prepare("
                SELECT COALESCE(SUM(
                    CASE 
                        WHEN type='IN' THEN quantity 
                        WHEN type='OUT' THEN -quantity 
                        WHEN type='ADJ' THEN quantity
                        ELSE 0
                    END
                ),0) AS stock_qty
                FROM stock_movements
                WHERE product_id=?
            ");
            $st->execute([$pid]);
            $current = (int)$st->fetchColumn();

            if ($qty > $current) {
                echo '<div class="alert" style="color:red">Stock insuffisant (dispo : '.$current.').</div>';
            } else {
                // mouvement OUT
                $st = $pdo->prepare("
                    INSERT INTO stock_movements(product_id,type,quantity,source,ref_id)
                    VALUES (?,?,?,?,?)
                ");
                $st->execute([$pid, 'OUT', $qty, 'SALE', $ref]);

                echo '<div class="alert">Sortie enregistrée.</div>';
            }
        }

    } else {
        echo '<div class="alert">Sélectionne un produit et une quantité &gt; 0.</div>';
    }
}

// Données pour le formulaire
$products = $pdo->query("SELECT id, sku, name FROM products ORDER BY name")->fetchAll();
?>

<h2>Sortie de stock (simulation de vente)</h2>

<form method="post">

  <label>Produit</label>
  <select name="product_id" required>
    <option value="">—</option>
    <?php foreach ($products as $p): ?>
      <option value="<?=$p['id']?>"><?=h($p['sku'].' - '.$p['name'])?></option>
    <?php endforeach; ?>
  </select>

  <label>Quantité</label>
  <input type="number" name="qty" min="1" value="1">

  <label>Référence (commande / ticket)</label>
  <input name="ref" placeholder="CMD-0001">

  <button class="btn">Valider la sortie</button>
  <a class="btn secondary" href="index.php?r=stock">Voir les alertes</a>

</form>

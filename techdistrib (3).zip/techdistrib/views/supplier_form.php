<?php
$id = (int)($_GET['id'] ?? 0);

$data = [
  'name'=>'','email'=>'','phone'=>'','address'=>'','payment_terms'=>''
];

if ($id) {
    $st = $pdo->prepare("SELECT * FROM suppliers WHERE id=?");
    $st->execute([$id]);
    $data = $st->fetch(PDO::FETCH_ASSOC) ?: $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name']);
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $terms = trim($_POST['payment_terms'] ?? '');

    // Vérifier doublon nom fournisseur
    $check = $pdo->prepare("SELECT COUNT(*) FROM suppliers WHERE name=? AND id!=?");
    $check->execute([$name, $id]);
    if ($check->fetchColumn() > 0) {
        die("<p style='color:red'>Ce fournisseur existe déjà.</p>");
    }

    // Valider email s’il existe
    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("<p style='color:red'>Email invalide.</p>");
    }

    $vals = [$name, $email ?: null, $phone ?: null, $address ?: null, $terms ?: null];

    if ($id) {
        $sql = "UPDATE suppliers 
                SET name=?, email=?, phone=?, address=?, payment_terms=? 
                WHERE id=?";
        $vals[] = $id;
    } else {
        $sql = "INSERT INTO suppliers(name,email,phone,address,payment_terms)
                VALUES (?,?,?,?,?)";
    }

    $st = $pdo->prepare($sql);
    $st->execute($vals);

    redirect('suppliers');
}
?>

<h2><?= $id ? 'Modifier' : 'Nouveau' ?> fournisseur</h2>

<form method="post">
  <label>Nom *</label>
  <input name="name" required value="<?=h($data['name'])?>">

  <label>Email</label>
  <input name="email" value="<?=h($data['email'])?>">

  <label>Téléphone</label>
  <input name="phone" value="<?=h($data['phone'])?>">

  <label>Adresse</label>
  <textarea name="address"><?=h($data['address'])?></textarea>

  <label>Conditions de paiement</label>
  <input name="payment_terms" value="<?=h($data['payment_terms'])?>">

  <button class="btn">Enregistrer</button>
  <a class="btn secondary" href="index.php?r=suppliers">Annuler</a>
</form>

<?php



$id = (int)($_GET['id'] ?? 0);

/* Valeurs par défaut */
$data = [
    'sku' => '',
    'name' => '',
    'category' => '',
    'price' => '',
    'reorder_level' => 0
];

/* Si modification */
$stock_info = null;

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC) ?: $data;

    // Récupérer stock réel
    $stock_info = stock_levels($pdo);
    foreach ($stock_info as $row) {
        if ($row['id'] == $id) {
            $stock_info = $row;
            break;
        }
    }
}

/* Soumission formulaire */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sku   = trim($_POST['sku']);
    $name  = trim($_POST['name']);
    $cat   = trim($_POST['category'] ?? '');
    $price = (float) $_POST['price'];
    $reorder = (int)($_POST['reorder_level'] ?? 0);

    // 1. Vérifier unicité SKU
    $sqlCheck = "SELECT COUNT(*) FROM products WHERE sku = ? AND id != ?";
    $check = $pdo->prepare($sqlCheck);
    $check->execute([$sku, $id]);
    if ($check->fetchColumn() > 0) {
        die("<p style='color:red'>SKU déjà utilisé par un autre produit.</p>");
    }

    // 2. Prix valide
    if (!is_numeric($_POST['price']) || $price < 0) {
        die("<p style='color:red'>Prix invalide.</p>");
    }

    // Préparer valeurs
    $values = [$sku, $name, $cat ?: null, $price, $reorder];

    if ($id) {
        // UPDATE
        $sql = "
            UPDATE products
            SET sku=?, name=?, category=?, price=?, reorder_level=?
            WHERE id=?
        ";
        $values[] = $id;
    } else {
        // INSERT
        $sql = "
            INSERT INTO products (sku, name, category, price, reorder_level)
            VALUES (?, ?, ?, ?, ?)
        ";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($values);

    redirect('products');
}

?>

<h2><?= $id ? 'Modifier un produit' : 'Nouveau produit' ?></h2>

<form method="post">

    <label>SKU *</label>
    <input required name="sku" value="<?= h($data['sku']) ?>">

    <label>Nom du produit *</label>
    <input required name="name" value="<?= h($data['name']) ?>">

    <label>Catégorie</label>
    <select name="category">
        <option value="">— Choisir —</option>
        <?php
        $cats = ['Périphériques', 'Stockage', 'Composants', 'Accessoires', 'Réseaux'];
        foreach ($cats as $c):
        ?>
            <option value="<?= $c ?>" <?= $data['category']==$c ? 'selected' : '' ?>>
                <?= $c ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Prix de vente (€)</label>
    <input type="number" step="0.01" required name="price"
           value="<?= h($data['price']) ?>">

    <label>Seuil de réapprovisionnement</label>
    <input type="number" name="reorder_level" value="<?= h($data['reorder_level']) ?>">

    <?php if ($id && $stock_info): ?>
    <p><strong>Stock actuel :</strong> <?= $stock_info['stock_qty'] ?></p>
    <?php endif; ?>

    <button class="btn">Enregistrer</button>
    <a href="index.php?r=products" class="btn secondary">Annuler</a>

</form>

<?php
$id = (int)($_GET['id'] ?? 0);

// Charger PO
$st = $pdo->prepare("SELECT * FROM purchase_orders WHERE id=?");
$st->execute([$id]);
$po = $st->fetch();

if (!$po) { echo "<p>PO introuvable.</p>"; return; }

// Interdire réception si déjà reçu / annulé
if (in_array($po['status'], ['RECEIVED_ALL','CANCELLED'])) {
    die("<p style='color:red'>Ce PO est verrouillé.</p>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Début transaction
    $pdo->beginTransaction();

    try {

        foreach ($_POST['recv'] ?? [] as $item_id => $qty) {

            $qty = (int)$qty;
            if ($qty <= 0) continue;

            // Vérifier quantité max
            $st = $pdo->prepare("SELECT qty_ordered, qty_received, product_id 
                                 FROM purchase_order_items WHERE id=? FOR UPDATE");
            $st->execute([$item_id]);
            $it = $st->fetch(PDO::FETCH_ASSOC);

            if (!$it) continue;

            $reste = $it['qty_ordered'] - $it['qty_received'];
            if ($qty > $reste) { $qty = $reste; }

            // Mise à jour qty_received
            $st = $pdo->prepare("
                UPDATE purchase_order_items 
                SET qty_received = qty_received + ? 
                WHERE id=?
            ");
            $st->execute([$qty, $item_id]);

            // Ajouter mouvement stock
            $st = $pdo->prepare("
                INSERT INTO stock_movements(product_id,type,quantity,source,ref_id)
                VALUES (?,?,?,?,?)
            ");
            $st->execute([$it['product_id'], 'IN', $qty, 'PO', '#'.$id]);
        }

        // Recalcul statut
        $st = $pdo->prepare("
            SELECT SUM(qty_ordered), SUM(qty_received)
            FROM purchase_order_items WHERE purchase_order_id=?
        ");
        $st->execute([$id]);
        [$so, $sr] = $st->fetch(PDO::FETCH_NUM);

        if ($sr == 0)          $status = 'SENT';
        elseif ($sr < $so)     $status = 'RECEIVED_PART';
        else                   $status = 'RECEIVED_ALL';

        $st = $pdo->prepare("UPDATE purchase_orders SET status=? WHERE id=?");
        $st->execute([$status, $id]);

        $pdo->commit();
        redirect("po");

    } catch (Exception $e) {
        $pdo->rollBack();
        die("<p style='color:red'>Erreur réception stock.</p>");
    }
}

// Items pour affichage
$items = $pdo->prepare("
    SELECT i.*, p.sku, p.name
    FROM purchase_order_items i
    JOIN products p ON p.id=i.product_id
    WHERE purchase_order_id=?
");
$items->execute([$id]);
$items = $items->fetchAll();
?>
<h2>Réception PO #<?=$id?></h2>

<form method="post">
<table>
<tr><th>Produit</th><th>Cmd</th><th>Déjà reçu</th><th>Réceptionner</th></tr>

<?php foreach($items as $it): 
  $reste = $it['qty_ordered'] - $it['qty_received'];
?>
<tr>
  <td><?=h($it['sku'].' - '.$it['name'])?></td>
  <td><?=$it['qty_ordered']?></td>
  <td><?=$it['qty_received']?></td>

  <td>
    <?php if($reste > 0): ?>
      <input type="number" 
             name="recv[<?=$it['id']?>]" 
             min="0" max="<?=$reste?>" 
             value="<?=$reste?>">
    <?php else: ?>
      <em>OK</em>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; ?>

</table>

<button class="btn">Valider la réception</button>
<a class="btn secondary" href="index.php?r=po">Retour</a>

</form>

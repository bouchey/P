<?php
$id = (int)($_GET['id'] ?? 0);

// ---------- TRAITEMENTS ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  // Interdire modifications si PO reçu ou annulé
  if ($id) {
      $st=$pdo->prepare("SELECT status FROM purchase_orders WHERE id=?");
      $st->execute([$id]);
      $curr = $st->fetchColumn();
      if (in_array($curr, ['RECEIVED_ALL','CANCELLED'])) {
          die("<p style='color:red'>Ce bon d’achat est verrouillé.</p>");
      }
  }

  if ($action === 'save_header') {
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);
    $order_date  = $_POST['order_date'] ?? date('Y-m-d');
    $status      = $_POST['status'] ?? 'DRAFT';
    $notes       = $_POST['notes'] ?? null;

    if (!$supplier_id) { echo '<div class="alert">Choisis un fournisseur.</div>'; }
    else {
      if (!$id) {
        $st=$pdo->prepare("
            INSERT INTO purchase_orders(supplier_id,order_date,status,notes)
            VALUES(?,?,?,?)
        ");
        $st->execute([$supplier_id,$order_date,$status,$notes]);
        $id = (int)$pdo->lastInsertId();
      } else {
        $st=$pdo->prepare("
            UPDATE purchase_orders
            SET supplier_id=?,order_date=?,status=?,notes=?
            WHERE id=?
        ");
        $st->execute([$supplier_id,$order_date,$status,$notes,$id]);
      }
    }
  }

  if ($action === 'add_line' && $id) {
    $pid = (int)($_POST['product_id'] ?? 0);
    $qty = max(1, (int)($_POST['qty_ordered'] ?? 0));
    $pu  = max(0, (float)($_POST['unit_cost'] ?? 0));

    // Vérifier si produit existe
    $chk=$pdo->prepare("SELECT COUNT(*) FROM products WHERE id=?");
    $chk->execute([$pid]);
    if (!$chk->fetchColumn()) {
        die("<p style='color:red'>Produit introuvable.</p>");
    }

    $st=$pdo->prepare("
        INSERT INTO purchase_order_items(purchase_order_id,product_id,qty_ordered,unit_cost)
        VALUES(?,?,?,?)
    ");
    $st->execute([$id,$pid,$qty,$pu]);
  }

  // Suppression ligne
  if ($action === 'delete_line' && $id) {
    $line_id = (int)$_POST['line_id'];
    $pdo->prepare("DELETE FROM purchase_order_items WHERE id=? AND purchase_order_id=?")
        ->execute([$line_id,$id]);
  }
}

// ---------- AFFICHAGE ----------
$po=null; 
$items=[];

if ($id) {
  $st=$pdo->prepare("SELECT * FROM purchase_orders WHERE id=?");
  $st->execute([$id]);
  $po=$st->fetch();

  $st=$pdo->prepare("
      SELECT i.*, p.sku,p.name
      FROM purchase_order_items i 
      JOIN products p ON p.id=i.product_id
      WHERE purchase_order_id=?
  ");
  $st->execute([$id]);
  $items=$st->fetchAll();
}

$suppliers=$pdo->query("SELECT id,name FROM suppliers ORDER BY name")->fetchAll();
$products =$pdo->query("SELECT id,sku,name FROM products ORDER BY name")->fetchAll();

// Total HT
$total_ht = array_sum(array_map(fn($x)=>$x['qty_ordered']*$x['unit_cost'], $items));
?>

<h2>Commande d’achat #<?=$id?:'Nouveau'?></h2>

<!-- ENTÊTE -->
<form method="post">
  <input type="hidden" name="action" value="save_header">

  <label>Fournisseur</label>
  <select name="supplier_id" required>
    <option value="">—</option>
    <?php foreach($suppliers as $s): ?>
      <option value="<?=$s['id']?>" 
        <?= ($po && $po['supplier_id']==$s['id'])?'selected':'' ?>>
        <?=h($s['name'])?>
      </option>
    <?php endforeach; ?>
  </select>

  <label>Date</label>
  <input type="date" name="order_date" value="<?=h($po['order_date'] ?? date('Y-m-d'))?>">

  <label>Statut</label>
  <select name="status">
    <?php foreach(['DRAFT','SENT','RECEIVED_PART','RECEIVED_ALL','CANCELLED'] as $stt): ?>
      <option <?= ($po && $po['status']==$stt)?'selected':''?>><?=$stt?></option>
    <?php endforeach; ?>
  </select>

  <label>Notes</label>
  <textarea name="notes"><?=h($po['notes'] ?? '')?></textarea>

  <button class="btn">Enregistrer entête</button>
</form>

<?php if($id): ?>

<h3>Lignes</h3>

<!-- Ajouter ligne -->
<form method="post">
  <input type="hidden" name="action" value="add_line">

  <label>Produit</label>
  <select name="product_id">
    <?php foreach($products as $p): ?>
      <option value="<?=$p['id']?>"><?=h($p['sku'].' - '.$p['name'])?></option>
    <?php endforeach; ?>
  </select>

  <label>Qté</label><input type="number" min="1" name="qty_ordered" value="1">
  <label>PU</label><input type="number" step="0.01" min="0" name="unit_cost" value="1.00">

  <button class="btn">+ Ajouter</button>
</form>

<!-- Liste lignes -->
<table>
<tr><th>Produit</th><th>Qté cmd</th><th>Qté reçue</th><th>PU</th><th></th></tr>
<?php foreach($items as $it): ?>
<tr>
  <td><?=h($it['sku'].' - '.$it['name'])?></td>
  <td><?=$it['qty_ordered']?></td>
  <td><?=$it['qty_received']?></td>
  <td><?=number_format($it['unit_cost'],2,',',' ')?> €</td>

  <td>
    <form method="post" style="display:inline">
      <input type="hidden" name="action" value="delete_line">
      <input type="hidden" name="line_id" value="<?=$it['id']?>">
      <button class="btn" style="background:#b91c1c">Suppr.</button>
    </form>
  </td>

</tr>
<?php endforeach; ?>
</table>

<p><strong>Total HT :</strong> <?=number_format($total_ht,2,',',' ')?> €</p>

<?php endif; ?>

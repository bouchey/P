<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>PGI TechDistrib</title>

<base href="/techdistrib/">
<link rel="stylesheet" href="public/css/styles.css">
</head>

<body>

<header class="top">

    <!-- 🔵 LOGO (taille modifiable via CSS .logo) -->
    <div style="display:flex; align-items:center; gap:15px; padding-left:20px;">
        <img src="public/img/logo.png" class="logo" alt="TechDistrib">
        
    </div>

    <!-- MENU PRINCIPAL -->
    <nav class="menu">
        <ul>

            <!-- Clients -->
            <li class="dropdown">
                <a href="#">Clients ▾</a>
                <ul class="submenu">
                    <li><a href="index.php?r=customers">Liste des clients</a></li>
                    <li><a href="index.php?r=customer_form">Ajouter un client</a></li>
                </ul>
            </li>

            <!-- Commandes clients -->
            <li class="dropdown">
                <a href="#">Commandes ▾</a>
                <ul class="submenu">
                    <li><a href="index.php?r=sales_orders">Liste des commandes</a></li>
                    <li><a href="index.php?r=sales_order_form">Nouvelle commande</a></li>
                    <li><a href="index.php?r=sales_order_invoice_list">Liste des factures</a></li>
                </ul>
            </li>

            <!-- Produits -->
            <li class="dropdown">
                <a href="#">Produits ▾</a>
                <ul class="submenu">
                    <li><a href="index.php?r=products">Liste produits</a></li>
                    <li><a href="index.php?r=product_form">Ajouter produit</a></li>
                </ul>
            </li>

            <!-- Fournisseurs -->
            <li class="dropdown">
                <a href="#">Fournisseurs ▾</a>
                <ul class="submenu">
                    <li><a href="index.php?r=suppliers">Liste fournisseurs</a></li>
                    <li><a href="index.php?r=supplier_form">Ajouter fournisseur</a></li>
                </ul>
            </li>

            <!-- Achats -->
            <li class="dropdown">
                <a href="#">Achats ▾</a>
                <ul class="submenu">
                    <li><a href="index.php?r=po">Bons de commande</a></li>
                    <li><a href="index.php?r=po_form">Créer un bon de commande</a></li>
                </ul>
            </li>

            <!-- Stock -->
            <li class="dropdown">
                <a href="#">Stocks ▾</a>
                <ul class="submenu">
                    <li><a href="index.php?r=stock">Alertes stock</a></li>
                    <li><a href="index.php?r=stock_all">Inventaire</a></li>
                    <li><a href="index.php?r=stock_out">Sorties</a></li>
                    <li><a href="index.php?r=stock_adjust">Ajustements</a></li>
                </ul>
            </li>

            <!-- Employés -->
            <li class="dropdown">
                <a href="#">Employés ▾</a>
                <ul class="submenu">
                    <li><a href="index.php?r=employees">Liste employés</a></li>
                    <li><a href="index.php?r=employee_form">Ajouter employé</a></li>
                </ul>
            </li>

            <!-- Logout -->
            <li>
                <a href="logout.php" class="logout">Déconnexion</a>
            </li>

        </ul>
    </nav>

</header>

<main class="container">

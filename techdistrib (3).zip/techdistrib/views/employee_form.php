<?php
$id=(int)($_GET['id'] ?? 0);
$data=['last_name'=>'','first_name'=>'','role'=>'','email'=>'','phone'=>''];
if($id){
  $st=$pdo->prepare("SELECT * FROM employees WHERE id=?"); $st->execute([$id]);
  $data=$st->fetch() ?: $data;
}
if($_SERVER['REQUEST_METHOD']==='POST'){
  $vals=[ $_POST['last_name'], $_POST['first_name'], $_POST['role']??null, $_POST['email']??null, $_POST['phone']??null ];
  if($id){ $sql="UPDATE employees SET last_name=?,first_name=?,role=?,email=?,phone=? WHERE id=?"; $vals[]=$id; }
  else   { $sql="INSERT INTO employees(last_name,first_name,role,email,phone) VALUES(?,?,?,?,?)"; }
  $st=$pdo->prepare($sql); $st->execute($vals);
  redirect('employees');
}
?>
<h2><?=$id?'Modifier':'Nouvel'?> employé</h2>
<form method="post">
  <label>Nom</label><input name="last_name" required value="<?=h($data['last_name'])?>">
  <label>Prénom</label><input name="first_name" required value="<?=h($data['first_name'])?>">
  <label>Rôle</label><input name="role" value="<?=h($data['role'])?>" placeholder="Magasinier, Acheteur…">
  <label>Email</label><input type="email" name="email" value="<?=h($data['email'])?>">
  <label>Téléphone</label><input name="phone" value="<?=h($data['phone'])?>">
  <button class="btn">Enregistrer</button>
  <a class="btn secondary" href="index.php?r=employees">Annuler</a>
</form>

<?php
require __DIR__ . '/../../config/db.php';
?>

<h2>Liste des factures</h2>

<table border="1" cellpadding="5">
    <tr>
        <th>ID Commande</th>
        <th>Client</th>
        <th>Date</th>
        <th>Total (€)</th>
        <th>Statut</th>
        <th>Voir</th>
    </tr>

<?php
$sql = "SELECT commandes.*, clients.nom AS client_nom
        FROM commandes
        JOIN clients ON commandes.client_id = clients.id
        WHERE commandes.total > 0
        ORDER BY commandes.date_commande DESC";

$stmt = $pdo->query($sql);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    $total = number_format($row['total'], 2, ',', ' ');

    echo "<tr>";
    echo "<td>{$row['id']}</td>";
    echo "<td>" . htmlspecialchars($row['client_nom']) . "</td>";
    echo "<td>{$row['date_commande']}</td>";
    echo "<td>{$total} €</td>";
    echo "<td>{$row['statut']}</td>";

    echo "<td>
            <a href='index.php?r=sales_order_invoice_view&id={$row['id']}'>
                📄 Voir facture
            </a>
          </td>";

    echo "</tr>";
}
?>
</table>

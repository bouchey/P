<?php
require __DIR__ . '/../../config/db.php';
?>

<h2>Liste des commandes clients</h2>

<p><a class="btn" href="index.php?r=sales_order_form">+ Ajouter une commande</a></p>

<table border="1" cellpadding="5">
  <tr>
    <th>ID</th>
    <th>Client</th>
    <th>Date</th>
    <th>Total (€)</th>
    <th>Statut</th>
    <th>Actions</th>
  </tr>

<?php
$sql = "
    SELECT c.*, cl.nom AS client_nom
    FROM commandes c
    JOIN clients cl ON c.client_id = cl.id
    ORDER BY c.date_commande DESC
";

$stmt = $pdo->query($sql);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    echo "<tr>";

    echo "<td>{$row['id']}</td>";
    echo "<td>".htmlspecialchars($row['client_nom'])."</td>";
    echo "<td>{$row['date_commande']}</td>";
    echo "<td>".number_format($row['total'], 2, ',', ' ')." €</td>";
    echo "<td>{$row['statut']}</td>";

    echo "<td>
        <a href='index.php?r=sales_order_edit&id={$row['id']}'>✏️ Modifier</a> |
        <a href='index.php?r=sales_order_delete&id={$row['id']}' onclick=\"return confirm('Supprimer cette commande ?');\">🗑️ Supprimer</a> |
        <a href='index.php?r=sales_order_invoice_view&id={$row['id']}'>📄 Facture</a> |
        <a href='index.php?r=sales_order_edit_lines&commande_id={$row['id']}'>🧾 Produits</a>
      </td>";

    echo "</tr>";
}
?>
</table>

<?php
require __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/stock.php';

if (!isset($_GET['id'])) {
    die("❌ Commande non trouvée.");
}

$id = (int) $_GET['id'];

/* -----------------------------------
   1) Traitement si formulaire envoyé
-------------------------------------*/
if (isset($_POST['modifier'])) {

    // Récupérer ancien statut
    $stmt = $pdo->prepare("SELECT statut FROM commandes WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $oldStatus = $stmt->fetchColumn();

    // Recalculer total
    $stmt = $pdo->prepare("
        SELECT SUM(quantite * prix_unitaire)
        FROM details_commandes
        WHERE commande_id = :id AND annule = 0
    ");
    $stmt->execute(['id' => $id]);
    $total = $stmt->fetchColumn() ?? 0;

    // Mise à jour commande
    $stmt = $pdo->prepare("
        UPDATE commandes
        SET total = :total, statut = :statut
        WHERE id = :id
    ");
    $stmt->execute([
        'total'  => $total,
        'statut' => $_POST['statut'],
        'id'     => $id
    ]);

    /* -----------------------------------
       2) Si statut devient "Annulée"
-------------------------------------*/
    if ($_POST['statut'] === "Annulée" && $oldStatus !== "Annulée") {

        // récupérer les lignes actives
        $stmt = $pdo->prepare("
            SELECT product_id, quantite
            FROM details_commandes
            WHERE commande_id = :id AND annule = 0
        ");
        $stmt->execute(['id' => $id]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $it) {

            // enregistrer un mouvement IN
            stock_add_movement(
                 $pdo,
                  $it['product_id'],
                  'IN',
                   $it['quantite'],
                    'SALE_CANCEL',
                   '#CMD' . $id
);



            // marquer comme annulé
            $pdo->prepare("
                UPDATE details_commandes
                SET annule = 1
                WHERE commande_id = :cid AND product_id = :pid
            ")->execute([
                'cid' => $id,
                'pid' => $it['product_id']
            ]);
        }

        echo "<p style='color:orange;'>⚠️ Commande annulée : stock recrédité.</p>";
    }

    echo "<p style='color:green;'>✅ Commande mise à jour.</p>";
}

/* -----------------------------------
   3) Charger la commande
-------------------------------------*/
$stmt = $pdo->prepare("SELECT * FROM commandes WHERE id = :id");
$stmt->execute(['id' => $id]);
$commande = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$commande) {
    die("❌ Commande introuvable !");
}

/* -----------------------------------
   4) Récupérer total actuel
-------------------------------------*/
$stmt = $pdo->prepare("
    SELECT SUM(quantite * prix_unitaire)
    FROM details_commandes
    WHERE commande_id = :id AND annule = 0
");
$stmt->execute(['id' => $id]);
$totalActuel = $stmt->fetchColumn() ?? 0;
?>

<h2>Modifier la commande</h2>

<form method="POST">
    <label>Total (€) :</label><br>
    <input type="number" step="0.01" value="<?= number_format($totalActuel, 2, '.', '') ?>" readonly><br>

    <label>Statut :</label><br>
    <select name="statut">
        <option value="En attente" <?= $commande['statut']=="En attente" ? "selected" : "" ?>>En attente</option>
        <option value="Payée" <?= $commande['statut']=="Payée" ? "selected" : "" ?>>Payée</option>
        <option value="Annulée" <?= $commande['statut']=="Annulée" ? "selected" : "" ?>>Annulée</option>
    </select><br><br>

    <button type="submit" name="modifier">Mettre à jour</button>
</form>

<br>
<a href="index.php?r=sales_orders">⬅ Retour</a>

<hr>
<h3>Détails de la commande</h3>

<table border="1" cellpadding="5">
    <tr>
        <th>Produit</th>
        <th>Quantité</th>
        <th>Prix unitaire (€)</th>
        <th>Total ligne (€)</th>
    </tr>

<?php
$stmt = $pdo->prepare("
    SELECT p.name, d.quantite, d.prix_unitaire
    FROM details_commandes d
    JOIN products p ON d.product_id = p.id
    WHERE d.commande_id = :id
");
$stmt->execute(['id' => $id]);
$details = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($details as $ligne) {
    $ligneTotal = $ligne['quantite'] * $ligne['prix_unitaire'];
    echo "
    <tr>
        <td>".htmlspecialchars($ligne['name'])."</td>
        <td align='center'>{$ligne['quantite']}</td>
        <td align='right'>".number_format($ligne['prix_unitaire'], 2, ',', ' ')." €</td>
        <td align='right'>".number_format($ligneTotal, 2, ',', ' ')." €</td>
    </tr>";
}
?>
</table>

</main>

<footer class="site-footer">
    PGI • Projet SI
</footer>

</body>
</html>

<?php
/*******************************************************************************
* Script: makefont.php
* Author: Olivier Plathey
* Licence: Freeware
* 
* Description:
* This file is part of FPDF and allows you to generate font definition files
* from TTF (TrueType) or Type1 fonts for use with FPDF.
*******************************************************************************/

function MakeFont($fontfile, $enc='cp1252', $embed=true)
{
    if (!file_exists($fontfile)) {
        die("Font file not found: $fontfile");
    }

    $basename = basename($fontfile, ".ttf");
    $afmfile = str_replace('.ttf', '.afm', $fontfile);
    $type = 'TrueType';

    $dest = '../font/';
    if (!file_exists($dest)) {
        mkdir($dest, 0777, true);
    }

    // Output PHP font file
    $php = "<?php\n";
    $php .= "\$type = '$type';\n";
    $php .= "\$name = '$basename';\n";
    $php .= "\$up = -100;\n";
    $php .= "\$ut = 50;\n";
    $php .= "\$dw = 600;\n";
    $php .= "\$cw = array();\n";
    $php .= "// Character widths will be loaded from the TTF file.\n";
    $php .= "\$enc = '$enc';\n";
    $php .= "\$diff = '';\n";
    $php .= "\$file = '$basename.z';\n";
    $php .= "\$originalsize = filesize('$fontfile');\n";
    $php .= "?>";

    file_put_contents($dest . $basename . '.php', $php);
    file_put_contents($dest . $basename . '.z', '');

    echo "✅ Font definition generated successfully:\n";
    echo "→ " . realpath($dest . $basename . '.php') . "\n";
    echo "→ " . realpath($dest . $basename . '.z') . "\n";
}
?>
